<?php
// Datos de conexión a la base de datos
$host = "localhost";      // Cambia si tu servidor es otro
$usuario = "tu_usuario";  // Cambia por tu usuario de base de datos
$password = "tu_contraseña"; // Cambia por tu contraseña de base de datos
$basedatos = "tu_base_de_datos"; // Cambia por el nombre de tu base de datos

// Crear la conexión
$conexion = mysqli_connect($host, $usuario, $password, $basedatos);

// Verificar la conexión
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Opcional: establecer el conjunto de caracteres
mysqli_set_charset($conexion, "utf8");
?>
