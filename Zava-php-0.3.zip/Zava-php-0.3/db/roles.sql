INSERT INTO Roles (nombre, descripcion) VALUES
('Administrador', 'Dar de baja productos, recetas, usuarios y negocios'),
('Usuario', 'Comentar y calificar restaurantes, productos y recetas, comprar productos y crear recetas'),
('Vendedor', 'Crear productos y publicar su restaurante');